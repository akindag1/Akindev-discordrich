local function publish()
    GlobalState.akinPlayerCount = #GetPlayers()
    GlobalState.akinMaxClients  = GetConvarInt('sv_maxclients', 48)
end

AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end

    publish()

    for _, btn in ipairs(Config.Buttons or {}) do
        if type(btn.url) == 'string' and btn.url:find('ipyaz', 1, true) then
            print('^3[Akindev-discordrich] UYARI: config.lua icindeki "ipyaz" yer tutucusunu gercek sunucu IP adresinizle degistirin.^7')
        end
    end
end)

AddEventHandler('playerJoining', function() SetTimeout(1000, publish) end)
AddEventHandler('playerDropped', function() SetTimeout(1000, publish) end)

CreateThread(function()
    while true do
        Wait(30000)
        publish()
    end
end)
