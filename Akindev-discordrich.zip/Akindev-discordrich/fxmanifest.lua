fx_version 'cerulean'
game       'gta5'
lua54      'yes'

name        'Akindev-discordrich'
author      'AkinDev'
description 'Discord Rich Presence - AkinDev RP'
version     '1.1.0'

shared_script 'config.lua'

client_script 'client.lua'
server_script 'server.lua'
