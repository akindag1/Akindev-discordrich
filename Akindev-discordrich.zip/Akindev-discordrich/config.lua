Config = {}

-- Discord Developer Portal > Uygulamaniz > Application ID
Config.AppID = '1358035381802500216'

Config.LargeImage     = 'Akindev3'
Config.LargeImageText = 'AkinDev RP'

Config.SmallImage     = 'Akindev1'
Config.SmallImageText = 'AkinDev'

Config.ServerName = 'AkinDev RP'

Config.UpdateInterval = 15000

Config.Buttons = {
    { text = 'Discord',         url = 'https://discord.gg/yncnr' },
    { text = 'Sunucuya Baglan', url = 'fivem://connect/ipyaz:30120' },
}
