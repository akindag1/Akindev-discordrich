Config = {}

-- Discord Developer Portal > Uygulamaniz > Application ID
Config.AppID = '1358035381802500216'

Config.LargeImage     = 'Akindev3'
Config.LargeImageText = 'AkinDev RP'

Config.SmallImage     = 'Akindev1'
Config.SmallImageText = 'AkinDev'

Config.ServerName = 'AkinDev RP'

-- Milisaniye. Discord guncelleme sinirlari nedeniyle en az 5000 kullanilir.
Config.UpdateInterval = 15000

-- Discord en fazla 2 buton gosterir.
-- Izin verilen adres bicimleri: https://... , http://... , fivem://...
Config.Buttons = {
    { text = 'Discord',         url = 'https://discord.gg/yncnr' },
    -- DIKKAT: 'ipyaz' yer tutucudur, kendi sunucu IP'nizi yazin. Ornek: fivem://connect/123.45.67.89:30120
    { text = 'Sunucuya Baglan', url = 'fivem://connect/ipyaz:30120' },
}
