local MIN_INTERVAL = 5000

local function clamp(str, maxLen)
    str = tostring(str or '')
    local len = utf8.len(str)
    if not len then return str:sub(1, maxLen) end
    if len <= maxLen then return str end
    return str:sub(1, utf8.offset(str, maxLen + 1) - 1)
end

local function validUrl(url)
    if type(url) ~= 'string' then return false end
    return url:match('^https?://%S+$') ~= nil or url:match('^fivem://%S+$') ~= nil
end


if type(Config) ~= 'table' or not Config.AppID or Config.AppID == '' then
    print('^1[Akindev-discordrich] Config.AppID tanimli degil, Rich Presence calismayacak.^7')
    return
end

SetDiscordAppId(Config.AppID)

SetDiscordRichPresenceAsset(Config.LargeImage)
SetDiscordRichPresenceAssetText(clamp(Config.LargeImageText, 128))
SetDiscordRichPresenceAssetSmall(Config.SmallImage)
SetDiscordRichPresenceAssetSmallText(clamp(Config.SmallImageText, 128))

do
    local slot = 0
    for _, btn in ipairs(Config.Buttons or {}) do
        if slot >= 2 then break end
        if type(btn) == 'table' and btn.text and validUrl(btn.url) then
            SetDiscordRichPresenceAction(slot, clamp(btn.text, 32), btn.url)
            slot = slot + 1
        else
            print(('^3[Akindev-discordrich] Gecersiz buton atlandi: %s^7'):format(json.encode(btn)))
        end
    end
end

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(500) end

    local interval = math.max(MIN_INTERVAL, tonumber(Config.UpdateInterval) or MIN_INTERVAL)
    local lastText

    while true do
        local serverId = GetPlayerServerId(PlayerId())
        local online   = GlobalState.akinPlayerCount or #GetActivePlayers()
        local maxSlots = GlobalState.akinMaxClients or GetConvarInt('sv_maxclients', 48)
        local text = clamp(('ID: %d - %s oynuyor | %d / %d Oyuncu'):format(
            serverId, Config.ServerName, online, maxSlots), 128)

        if text ~= lastText then
            SetRichPresence(text)
            lastText = text
        end

        Wait(interval)
    end
end)
